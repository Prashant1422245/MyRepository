package com.cg.cms.exception;

public class CustomerNotFoundException extends Exception {

}
