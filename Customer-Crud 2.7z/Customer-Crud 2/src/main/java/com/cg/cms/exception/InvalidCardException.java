package com.cg.cms.exception;

public class InvalidCardException extends Exception{

}
